param(
    [string]$OutputPath = "",
    [string]$InternalBaseUrl = "https://dpl-acron.intern",
    [switch]$SkipTests
)

$ErrorActionPreference = "Stop"
$projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot "..")).Path
if (-not $OutputPath) {
    $OutputPath = Join-Path $projectRoot "dist\internal-repository"
}
$repositoryRoot = [IO.Path]::GetFullPath($OutputPath)
$releaseBundle = Join-Path $projectRoot "dist\dpl-acron-debian13.tar.gz"

if ($SkipTests) {
    & (Join-Path $PSScriptRoot "build-bundle.ps1") -SkipTests
}
else {
    & (Join-Path $PSScriptRoot "build-bundle.ps1")
}
if ($LASTEXITCODE -ne 0) {
    throw "Das Release-Bundle konnte nicht erstellt werden."
}

$runtime = Get-Content -LiteralPath (Join-Path $projectRoot "dpl_export\runtime.py") -Raw
$versionMatch = [regex]::Match($runtime, 'APP_VERSION\s*=\s*"([^"]+)"')
if (-not $versionMatch.Success) {
    throw "APP_VERSION konnte nicht ermittelt werden."
}
$appVersion = $versionMatch.Groups[1].Value
$releaseDirectory = Join-Path $repositoryRoot "releases\$appVersion"
$ctDirectory = Join-Path $repositoryRoot "ct"
$installDirectory = Join-Path $repositoryRoot "install"
$jsonDirectory = Join-Path $repositoryRoot "json"
$docsDirectory = Join-Path $repositoryRoot "docs"
$testDirectory = Join-Path $repositoryRoot "test"
New-Item -ItemType Directory -Force -Path $releaseDirectory, $ctDirectory, $installDirectory, $jsonDirectory, $docsDirectory, $testDirectory | Out-Null

$publishedBundle = Join-Path $releaseDirectory "dpl-acron-debian13.tar.gz"
$publishedInstaller = Join-Path $releaseDirectory "proxmox-install-lxc.sh"
Copy-Item -LiteralPath $releaseBundle -Destination $publishedBundle -Force
Copy-Item -LiteralPath (Join-Path $PSScriptRoot "proxmox-install-lxc.sh") -Destination $publishedInstaller -Force

$bundleHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $publishedBundle).Hash.ToLowerInvariant()
$installerHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $publishedInstaller).Hash.ToLowerInvariant()
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$communityTemplate = Get-Content -LiteralPath (Join-Path $PSScriptRoot "community-ct.sh") -Raw
$communityScript = $communityTemplate.Replace("@@APP_VERSION@@", $appVersion)
$communityScript = $communityScript.Replace("@@BUNDLE_SHA256@@", $bundleHash)
$communityPath = Join-Path $ctDirectory "dpl-acron.sh"
[IO.File]::WriteAllText($communityPath, $communityScript, $utf8NoBom)

$containerInstaller = Join-Path $installDirectory "dpl-acron-install.sh"
Copy-Item -LiteralPath (Join-Path $PSScriptRoot "community-install.sh") -Destination $containerInstaller -Force
$communityHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $communityPath).Hash.ToLowerInvariant()
$entryTemplate = Get-Content -LiteralPath (Join-Path $PSScriptRoot "install-proxmox-entry.sh") -Raw
$entryScript = $entryTemplate.Replace("@@COMMUNITY_SHA256@@", $communityHash)
$entryPath = Join-Path $repositoryRoot "install-proxmox.sh"
[IO.File]::WriteAllText($entryPath, $entryScript, $utf8NoBom)
$entryHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $entryPath).Hash.ToLowerInvariant()
$bootstrapTemplate = Get-Content -LiteralPath (Join-Path $PSScriptRoot "bootstrap-proxmox.sh") -Raw
$bootstrapScript = $bootstrapTemplate.Replace("@@BASE_URL@@", $InternalBaseUrl.TrimEnd('/'))
$bootstrapScript = $bootstrapScript.Replace("@@ENTRY_SHA256@@", $entryHash)
$bootstrapPath = Join-Path $repositoryRoot "bootstrap-proxmox.sh"
[IO.File]::WriteAllText($bootstrapPath, $bootstrapScript, $utf8NoBom)
$bootstrapHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $bootstrapPath).Hash.ToLowerInvariant()
$containerInstallerHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $containerInstaller).Hash.ToLowerInvariant()
$acceptanceTest = Join-Path $testDirectory "proxmox-acceptance.sh"
Copy-Item -LiteralPath (Join-Path $PSScriptRoot "proxmox-acceptance.sh") -Destination $acceptanceTest -Force
$acceptanceTestHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $acceptanceTest).Hash.ToLowerInvariant()

# Sicherheitsrelevante Bedienungsanleitungen werden aus einer Quelle erzeugt.
# Dadurch stammen die dort verwendeten Prüfsummen immer aus genau diesem Build.
$proxmoxCtGuide = Get-Content -LiteralPath (Join-Path $projectRoot "PROXMOX_CT.md") -Raw
$proxmoxCtGuide = $proxmoxCtGuide.Replace("PROXMOX_BOOTSTRAP_SHA256", $bootstrapHash)
$proxmoxCtGuide = $proxmoxCtGuide.Replace("COMMUNITY_SCRIPT_SHA256", $communityHash)
[IO.File]::WriteAllText((Join-Path $docsDirectory "PROXMOX_CT.md"), $proxmoxCtGuide, $utf8NoBom)
$proxmoxTestGuide = Get-Content -LiteralPath (Join-Path $projectRoot "PROXMOX_TEST.md") -Raw
$proxmoxTestGuide = $proxmoxTestGuide.Replace("PROXMOX_BOOTSTRAP_SHA256", $bootstrapHash)
$proxmoxTestGuide = $proxmoxTestGuide.Replace("EINSTIEGSSKRIPT_SHA256", $communityHash)
$proxmoxTestGuide = $proxmoxTestGuide.Replace("ABNAHMESKRIPT_SHA256", $acceptanceTestHash)
[IO.File]::WriteAllText((Join-Path $docsDirectory "PROXMOX_TEST.md"), $proxmoxTestGuide, $utf8NoBom)

$metadata = [ordered]@{
    name = "DPL2ACRON"
    slug = "dpl-acron"
    categories = @(8, 19, 25)
    date_created = "2026-09-07"
    description = "Interner Dienst zur DPL-Prüfung und Erzeugung von ACRON-Exportdateien mit lokaler MariaDB."
    type = "ct"
    updateable = $true
    privileged = $false
    interface_port = 443
    documentation = "$($InternalBaseUrl.TrimEnd('/'))/docs/PROXMOX_CT.md"
    website = "$($InternalBaseUrl.TrimEnd('/'))/"
    repository = "$($InternalBaseUrl.TrimEnd('/'))/"
    architectures = @("amd64")
    platforms = @("pve")
    logo = "$($InternalBaseUrl.TrimEnd('/'))/assets/agw-logo.png"
    install_methods = @(
        [ordered]@{
            type = "default"
            script = "ct/dpl-acron.sh"
            config_path = "/etc/dpl-acron/database.env"
            resources = [ordered]@{
                cpu = 2
                ram = 2048
                hdd = 8
                os = "Debian"
                version = "13"
            }
        }
    )
    default_credentials = [ordered]@{ username = "admin"; password = $null }
    notes = @(
        [ordered]@{ text = "Nur über Intranet oder VPN veröffentlichen."; type = "warning" }
    )
}
[IO.File]::WriteAllText((Join-Path $jsonDirectory "dpl-acron.json"), ($metadata | ConvertTo-Json -Depth 4), $utf8NoBom)
New-Item -ItemType Directory -Force -Path (Join-Path $repositoryRoot "assets") | Out-Null
Copy-Item -LiteralPath (Join-Path $projectRoot "dpl_export\web\assets\agw-logo.png") -Destination (Join-Path $repositoryRoot "assets\agw-logo.png") -Force

$manifest = [ordered]@{
    application = "DPL2ACRON"
    version = $appVersion
    bundle = "releases/$appVersion/dpl-acron-debian13.tar.gz"
    bundle_sha256 = $bundleHash
    installer = "releases/$appVersion/proxmox-install-lxc.sh"
    installer_sha256 = $installerHash
    community_script = "ct/dpl-acron.sh"
    community_script_sha256 = $communityHash
    proxmox_entry = "install-proxmox.sh"
    proxmox_entry_sha256 = $entryHash
    proxmox_bootstrap = "bootstrap-proxmox.sh"
    proxmox_bootstrap_sha256 = $bootstrapHash
    community_install = "install/dpl-acron-install.sh"
    community_install_sha256 = $containerInstallerHash
    acceptance_test = "test/proxmox-acceptance.sh"
    acceptance_test_sha256 = $acceptanceTestHash
}
$manifestJson = $manifest | ConvertTo-Json
[IO.File]::WriteAllText((Join-Path $repositoryRoot "release.json"), $manifestJson, $utf8NoBom)

Write-Host "Internes Repository erstellt: $repositoryRoot"
Write-Host "Version: $appVersion"
Write-Host "Community Script: $communityPath"
Write-Host "Community Script SHA-256: $communityHash"
Write-Host "Weitergabe-Installer: $entryPath"
Write-Host "Weitergabe-Installer SHA-256: $entryHash"
Write-Host "Kanonischer Proxmox-Bootstrap: $bootstrapPath"
Write-Host "Kanonischer Proxmox-Bootstrap SHA-256: $bootstrapHash"
Write-Host "Veröffentlichen Sie den gesamten Ordner unverändert über internes HTTPS."
