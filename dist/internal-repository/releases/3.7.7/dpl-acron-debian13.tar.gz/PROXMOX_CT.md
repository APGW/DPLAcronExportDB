# Proxmox-LXC für DPL2ACRON

## Empfohlener Aufbau

Der Dienst läuft in einem unprivilegierten Debian-13-LXC mit eigener privater
IP. MariaDB und Anwendung befinden sich im selben Container; Port `3306` wird
nicht ins Netzwerk freigegeben.

- 2 vCPU
- 2 GB RAM und 512 MB Swap
- mindestens 8 GB Root-Disk
- Autostart aktiviert
- Proxmox-Firewall an der CT-Netzwerkkarte aktiviert
- kein Docker, `nesting` oder privilegierter Container erforderlich

Das primäre Verfahren verwendet einen internen, Community-Scripts-kompatiblen
Einstiegspunkt. `ct/dpl-acron.sh` prüft zuerst das vollständige Release und
startet erst danach den darin enthaltenen LXC-Installer. Dadurch wird kein
veränderlicher Fremdcode als Proxmox-root ausgeführt.

## Empfohlen: Ein-Befehl-Installation aus dem internen Repository

Das Projekt erzeugt ein statisches internes Repository, das beispielsweise über
einen internen IIS-, Nginx- oder Artefaktserver per HTTPS bereitgestellt werden
kann. Es enthält die standardisierten Verzeichnisse `ct/`, `install/` und
`json/`, die Metadaten sowie das geprüfte Anwendungsrelease.

Einmalig auf dem Windows-Entwicklungsrechner erstellen:

```powershell
.\deploy\build-internal-repository.ps1
```

Danach den vollständigen Ordner `dist\internal-repository` unverändert unter
einer internen HTTPS-Adresse veröffentlichen, zum Beispiel:

```text
https://software.intern/dpl-acron/
```

Der Build erzeugt zusätzlich `bootstrap-proxmox.sh`. Dieses Skript ist die
kanonische äußere Vertrauensgrenze: Es lädt `install-proxmox.sh` in ein neues
privates Verzeichnis, prüft den beim Build eingebetteten SHA-256-Wert und führt
den Installer nur bei erfolgreicher Prüfung aus. Seine eigene Prüfsumme steht
in `release.json` und muss über einen vertrauenswürdigen Freigabekanal bezogen
werden.

In der Proxmox-Browserkonsole als `root` wird der Bootstrap als ein
zusammenhängender, fail-closed Block geladen, geprüft und gestartet. Den
Platzhalter durch die freigegebene Prüfsumme aus `release.json` ersetzen:

```bash
(
  set -Eeuo pipefail
  umask 077
  BOOTSTRAP_DIR="$(/usr/bin/mktemp -d -p /root .dpl2acron-bootstrap.XXXXXX)"
  trap '/bin/rm -rf -- "$BOOTSTRAP_DIR"' EXIT
  /usr/bin/curl --disable --proto '=https' --proto-redir '=https' --tlsv1.2 \
    --connect-timeout 10 --max-time 60 --speed-limit 1024 --speed-time 15 \
    --max-filesize 1048576 -fsS \
    https://software.intern/dpl-acron/bootstrap-proxmox.sh \
    -o "$BOOTSTRAP_DIR/bootstrap-proxmox.sh"
  printf '%s  %s\n' 'PROXMOX_BOOTSTRAP_SHA256' "$BOOTSTRAP_DIR/bootstrap-proxmox.sh" | \
    /usr/bin/sha256sum --check --status -
  /usr/bin/env -i HOME=/root PATH=/usr/sbin:/usr/bin:/sbin:/bin TERM="${TERM:-xterm}" \
    DPL_BASE_URL="https://software.intern/dpl-acron" \
    WEB_CIDRS="192.168.133.0/24,10.250.0.0/24" \
    /bin/bash --noprofile --norc -p "$BOOTSTRAP_DIR/bootstrap-proxmox.sh"
)
```

Vor der Containererstellung wird das Administratorkennwort verdeckt zweimal
abgefragt. Der Benutzername ist `admin`. Das Kennwort wird weder in den Befehl
noch in das Repository geschrieben.

Die Adresse, Prüfsumme und Netze sind Beispiele und müssen ersetzt werden. Das
CT-Skript lädt das festgelegte Release ausschließlich aus dem internen
Repository. Die Release-Prüfsumme ist im CT-Skript verankert. Erst nach ihrer
erfolgreichen Prüfung wird der enthaltene Installer ausgeführt.

Bei einer internen Zertifizierungsstelle muss deren CA-Zertifikat auf dem
Proxmox-Host vorhanden sein. Es wird sowohl für den ersten als auch für alle
folgenden Downloads angegeben:

```bash
(
  set -Eeuo pipefail
  umask 077
  BOOTSTRAP_DIR="$(/usr/bin/mktemp -d -p /root .dpl2acron-bootstrap.XXXXXX)"
  trap '/bin/rm -rf -- "$BOOTSTRAP_DIR"' EXIT
  /usr/bin/curl --disable --cacert /usr/local/share/ca-certificates/firma.crt \
    --proto '=https' --proto-redir '=https' --tlsv1.2 --connect-timeout 10 \
    --max-time 60 --speed-limit 1024 --speed-time 15 --max-filesize 1048576 -fsS \
    https://software.intern/dpl-acron/bootstrap-proxmox.sh \
    -o "$BOOTSTRAP_DIR/bootstrap-proxmox.sh"
  printf '%s  %s\n' 'PROXMOX_BOOTSTRAP_SHA256' "$BOOTSTRAP_DIR/bootstrap-proxmox.sh" | \
    /usr/bin/sha256sum --check --status -
  /usr/bin/env -i HOME=/root PATH=/usr/sbin:/usr/bin:/sbin:/bin TERM="${TERM:-xterm}" \
    DPL_BASE_URL="https://software.intern/dpl-acron" \
    DPL_CA_CERT="/usr/local/share/ca-certificates/firma.crt" \
    WEB_CIDRS="192.168.133.0/24,10.250.0.0/24" \
    /bin/bash --noprofile --norc -p "$BOOTSTRAP_DIR/bootstrap-proxmox.sh"
)
```

`curl -k` soll nicht verwendet werden, weil dadurch die Serveridentität nicht
mehr geprüft wird.

### Temporär vom lokalen Windows-Rechner bereitstellen

Für einen Test ohne vorhandenen internen Webserver kann der erzeugte Ordner
kurzzeitig im lokalen Netz bereitgestellt werden. Weil dabei HTTP verwendet
wird, muss der Bootstrap vor seiner Ausführung gegen den auf dem
Entwicklungsrechner ermittelten SHA-256-Wert geprüft werden. Erst danach wird
`DPL_ALLOW_HTTP=1` gesetzt. Diese Variante ist nur für ein kontrolliertes lokales
Netz vorgesehen; für den Dauerbetrieb ist internes HTTPS zu verwenden.

Der lokale Server stellt ausschließlich `dist\internal-repository` bereit. In
der Proxmox-Shell wird das Community Script zunächst nach `/tmp` geladen, geprüft und
danach ausgeführt:

```bash
(
  set -Eeuo pipefail
  umask 077
  BOOTSTRAP_DIR="$(/usr/bin/mktemp -d -p /root .dpl2acron-http-test.XXXXXX)"
  trap '/bin/rm -rf -- "$BOOTSTRAP_DIR"' EXIT
  /usr/bin/curl --disable --proto '=http' --proto-redir '=http' \
    --connect-timeout 10 --max-time 60 --speed-limit 1024 --speed-time 15 \
    --max-filesize 1048576 -fsS \
    http://WINDOWS-IP:8088/ct/dpl-acron.sh -o "$BOOTSTRAP_DIR/dpl-acron.sh"
  printf '%s  %s\n' 'COMMUNITY_SCRIPT_SHA256' "$BOOTSTRAP_DIR/dpl-acron.sh" | \
    /usr/bin/sha256sum --check --status -
  /usr/bin/env -i HOME=/root PATH=/usr/sbin:/usr/bin:/sbin:/bin TERM="${TERM:-xterm}" \
    DPL_ALLOW_HTTP=1 DPL_BASE_URL="http://WINDOWS-IP:8088" \
    WEB_CIDRS="IHR-LAN/CIDR,IHR-VPN/CIDR" \
    /bin/bash --noprofile --norc -p "$BOOTSTRAP_DIR/dpl-acron.sh"
)
```

Auch diese Variante fragt das Administratorkennwort interaktiv und verdeckt ab.

## Alternative: automatische Vollinstallation mit lokalem Release

Zuerst diese drei Dateien auf den Proxmox-Host kopieren:

- `dpl-acron-debian13.tar.gz`
- `dpl-acron-debian13.tar.gz.sha256`
- `proxmox-install-lxc.sh`

Beispiel vom Windows-Rechner, ausgeführt im Projektverzeichnis:

```powershell
scp .\dist\dpl-acron-debian13.tar.gz root@PVE-IP:/root/
scp .\dist\dpl-acron-debian13.tar.gz.sha256 root@PVE-IP:/root/
scp .\deploy\proxmox-install-lxc.sh root@PVE-IP:/root/
ssh root@PVE-IP
```

Auf dem Proxmox-Host installieren:

```bash
chmod 700 /root/proxmox-install-lxc.sh
/usr/bin/env -i HOME=/root PATH=/usr/sbin:/usr/bin:/sbin:/bin TERM="${TERM:-xterm}" \
  CTID=3072 WEB_CIDRS="192.168.133.0/24,10.250.0.0/24" \
  SSH_CIDRS="192.168.133.0/24" SSH_PUBLIC_KEYS="/root/.ssh/authorized_keys" \
  /bin/bash --noprofile --norc -p /root/proxmox-install-lxc.sh
```

Das Skript fragt das Administratorkennwort verdeckt ab und überträgt es nur für
die einmalige Hash-Erzeugung an den Container.

Da Archiv, Prüfsumme und Skript gemeinsam unter `/root` liegen, wird das Bundle
automatisch erkannt. `BUNDLE_PATH` ist nur nötig, wenn es an einem anderen Ort
liegt.

`WEB_CIDRS` ist verpflichtend. Die Beispielnetze müssen durch die tatsächlichen
LAN- und VPN-Netze ersetzt werden. Mehrere Netze werden mit Komma getrennt.
`SSH_CIDRS` und `SSH_PUBLIC_KEYS` sind optional; ohne SSH-Freigabe erfolgt die
Administration über `pct enter 3072` auf dem Proxmox-Host.

Standardmäßig verwendet das Skript DHCP, `local-lvm`, `local` und `vmbr0`. Eine
statische IP und abweichende Speicher lassen sich so setzen:

```bash
/usr/bin/env -i HOME=/root PATH=/usr/sbin:/usr/bin:/sbin:/bin TERM="${TERM:-xterm}" \
  CTID=3072 CT_HOSTNAME=dpl-acron ROOT_STORAGE=local-lvm TEMPLATE_STORAGE=local \
  BRIDGE=vmbr0 IP_CONFIG=192.168.133.130/24 GATEWAY=192.168.133.2 \
  WEB_CIDRS="192.168.133.0/24,10.250.0.0/24" SSH_CIDRS="192.168.133.0/24" \
  /bin/bash --noprofile --norc -p /root/proxmox-install-lxc.sh
```

Für VLAN 100 muss die gewählte Linux-Bridge VLAN-aware sein und der physische
Switchport VLAN 100 getaggt transportieren. Bei der empfohlenen VLAN-aware
Bridge `vmbr0` wird der Tag bereits während der CT-Erstellung gesetzt:

```bash
/usr/bin/env -i HOME=/root PATH=/usr/sbin:/usr/bin:/sbin:/bin TERM="${TERM:-xterm}" \
  CTID=3072 BRIDGE=vmbr0 VLAN_TAG=100 \
  WEB_CIDRS="192.168.100.0/24,10.250.0.0/24" \
  /bin/bash --noprofile --norc -p /root/proxmox-install-lxc.sh
```

Der Installer akzeptiert VLAN-IDs von 1 bis 4094 und bricht ab, wenn die Bridge
nicht existiert oder zur Laufzeit kein VLAN-Filtering aktiviert ist. DHCP-Relay,
DHCP-Server, Gateway und Routing für VLAN 100 werden nicht vom Installer
eingerichtet und müssen im Netzwerk bereits vorhanden sein.

Das Release kann alternativ von einer internen HTTPS-Adresse geladen werden.
Die erwartete Prüfsumme muss dabei ausdrücklich angegeben werden:

```bash
/usr/bin/env -i HOME=/root PATH=/usr/sbin:/usr/bin:/sbin:/bin TERM="${TERM:-xterm}" \
  CTID=3072 WEB_CIDRS="192.168.133.0/24,10.250.0.0/24" \
  BUNDLE_URL="https://software.intern/dpl-acron-debian13.tar.gz" \
  BUNDLE_SHA256="HIER_64_HEX_ZEICHEN_EINTRAGEN" \
  DPL_CA_CERT="/usr/local/share/ca-certificates/firma.crt" \
  /bin/bash --noprofile --norc -p /root/proxmox-install-lxc.sh
```

`DPL_CA_CERT` ist nur bei einer privaten Zertifizierungsstelle erforderlich.
Das geprüfte Zertifikat wird root-geschützt in den Container übernommen und
für spätere Updates in `/etc/dpl-acron/update.env` hinterlegt.

Das Skript bricht ab, wenn die CT-ID bereits vorhanden ist, die Prüfsumme nicht
passt, kein Debian-13-Template verfügbar ist oder der Container die
Debian-Paketquellen nicht erreicht. Ein nach der Erstellung auftretender Fehler
lässt den Container zur Diagnose bestehen; er wird nicht automatisch gelöscht.
Ein eindeutig als `dpl-acron` markierter, unprivilegierter Debian-Container kann
nach einem abgebrochenen Lauf mit `RESUME_EXISTING=1` fortgesetzt werden. Er muss
dazu gestoppt sein. Fremde oder laufende Container werden nicht übernommen.

## Einordnung zu Proxmox VE Community Scripts

Die Community-Scripts-Dokumentation trennt dieselben zwei Ausführungsebenen:

- `ct/*.sh` läuft auf dem Proxmox-Host und erstellt den Container.
- `install/*.sh` läuft innerhalb des Containers und richtet die Anwendung ein.

In diesem Projekt entsprechen dem:

| Community-Scripts-Rolle | Datei dieses Projekts | Ausführungsort |
| --- | --- | --- |
| Container Script | `deploy/community-ct.sh`, veröffentlicht als `ct/dpl-acron.sh` | Proxmox-Host |
| Installation Script | `deploy/community-install.sh`, veröffentlicht als `install/dpl-acron-install.sh` | Debian-13-LXC |
| Anwendungsinstallation | `deploy/install-debian13.sh` im geprüften Release | Debian-13-LXC |
| Metadaten | `json/dpl-acron.json` | internes Repository |

Der veröffentlichte Einstiegspunkt bewahrt die Ein-Befehl-Bedienung, ruft aber
keine veränderliche Community-Scripts-Engine auf. Containererstellung, Firewall
und Installation stammen aus demselben per SHA-256 geprüften Release.

## Was ist ein Post-Install-Skript?

Der Begriff wird in zwei verwandten Bedeutungen verwendet:

1. Debian-Pakete können ein `postinst`-Maintainer-Skript enthalten, das nach dem
   Entpacken und Konfigurieren des Pakets ausgeführt wird.
2. Bei der Systembereitstellung bezeichnet „Post-Install“ meist ein Skript, das
   nach Erstellung des Betriebssystems beziehungsweise Containers die konkrete
   Anwendung einrichtet.

Im Sprachgebrauch der Community-Scripts-Dokumentation heißt diese zweite Stufe
„Installation Script“. Für dieses Projekt gilt entsprechend:

```text
Proxmox-Host
└─ ct/dpl-acron.sh              Community-Scripts-Dialog und LXC-Erstellung
   └─ install/dpl-acron-install.sh  Installation innerhalb des LXC
      └─ install-debian13.sh    Anwendung und lokale MariaDB
      ├─ installiert Python, MariaDB und Connector
      ├─ erzeugt lokalen DB-Benutzer und Schema
      ├─ installiert Anwendung und systemd-Dienste
      ├─ aktiviert tägliche Datenbanksicherungen
      └─ prüft abschließend /api/health
```

Das Post-Install-Skript ist wiederholt ausführbar und dient zugleich für spätere
Updates. Zugangsdaten und Projektdaten bleiben dabei erhalten; vor einer
Schemamigration wird eine MariaDB-Sicherung erstellt. Das Skript wird aus einem
lokal geprüften Release aufgerufen und nicht unkontrolliert über `curl | bash`.

## Firewall und Erreichbarkeit

Das Hostskript legt `/etc/pve/firewall/<CTID>.fw` mit eingehender
Standardrichtlinie `DROP` an. Es erlaubt:

- ICMP für Diagnose
- bei DHCP die notwendige DHCP-Antwort
- `443/tcp` ausschließlich aus `WEB_CIDRS`
- optional `22/tcp` ausschließlich aus `SSH_CIDRS`

Der Installer prüft vor dem ersten Containerstart, dass die Firewall unter
`Datacenter > Firewall > Options` aktiviert ist und auf dem aktuellen Node
der zur Node-Option `nftables` passende Dienst aktiv ist:
`proxmox-firewall.service` bei aktivem nftables-Backend, andernfalls
`pve-firewall.service`. Er
ändert diese gemeinsam genutzten Hosteinstellungen nicht automatisch. Eine
separate Node-Host-Firewalloption ist nur für Regeln des Proxmox-Hosts selbst
zuständig und keine Voraussetzung für die CT-Regeln. Es darf weder am
Internet-Router noch an
einer vorgeschalteten Firewall eine öffentliche Weiterleitung für `443`
oder `3306` auf diesen Container geben. VPN-Clients greifen per Routing auf die
private CT-IP zu.

Der Container wird zunächst mit deaktiviertem Autostart erstellt. Erst nach
erfolgreicher Installation und bestandener lokaler Gesundheitsprüfung setzt der
Installer `onboot=1`. Bei einer fehlgeschlagenen Firewallprüfung bleibt der
Container gestoppt und startet auch nach einem Hostneustart nicht automatisch.

## Wiederverwendbare CT-Vorlage

Eine Basissystemvorlage darf keine Anwendungsdaten oder erzeugten
Datenbankkennwörter enthalten:

1. Debian-13-LXC erstellen.
2. Nur das Basissystem aktualisieren.
3. LXC sauber herunterfahren.
4. Auf dem Proxmox-Host `pct template BASIS-CTID` ausführen.
5. Mit `pct clone BASIS-CTID NEUE-CTID --full 1` klonen.
6. Erst im Klon das geprüfte Release und `install-debian13.sh` ausführen.

Für eine einzelne Instanz ist das vollständige Installationsskript einfacher
und verhindert, dass Kennwörter, Projektdaten oder Sicherungen mitgeklont
werden.

## Vorhandenen Debian-13-LXC verwenden

In einem bereits vorhandenen Container reicht die Installation aus
[DEPLOY_DEBIAN13.md](DEPLOY_DEBIAN13.md). MariaDB muss nicht vorinstalliert
sein; das Post-Install-Skript installiert und aktiviert sie bei Bedarf. Die
Netzwerkfreigabe muss dennoch auf LAN und VPN begrenzt werden.

Offizielle Referenzen:

- [Proxmox `pct` – Container Toolkit](https://pve.proxmox.com/pve-docs-9-beta/pct.1.html)
- [Debian-Wiki: MariaDB](https://wiki.debian.org/Mariadb)
- [Debian Policy: Maintainer- und `postinst`-Skripte](https://www.debian.org/doc/debian-policy/ch-maintainerscripts.html)
- [Community Scripts: Container Scripts](https://community-scripts.org/docs/ct/readme)
- [Community Scripts: Installation Scripts](https://community-scripts.org/docs/install/readme)
